"""Demo application for a GitHub security pipeline course project.

The code intentionally contains small educational patterns that can be
reported by security tools. Do not copy these patterns to production code.
"""

import subprocess
from flask import Flask, jsonify, request

app = Flask(__name__)

# Educational pseudo-secret. It is not a real credential.
DEMO_TOKEN = "DEMO_TOKEN_TURIN_VM_FOR_SECURITY_PIPELINE_ONLY"


def add(a: int, b: int) -> int:
    return a + b


@app.get("/health")
def health():
    return jsonify({"status": "ok"})


@app.post("/calculate")
def calculate():
    body = request.get_json(silent=True) or {}
    a = int(body.get("a", 0))
    b = int(body.get("b", 0))
    return jsonify({"result": add(a, b)})


def unsafe_demo_command(user_input: str) -> str:
    """Educational insecure example for SAST demonstration only."""
    completed = subprocess.run(
        f"echo {user_input}",
        shell=True,
        text=True,
        capture_output=True,
        check=False,
    )
    return completed.stdout.strip()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8080)
