# security-pipeline-turin-vm

Учебный репозиторий для курсовой работы студента **Тюрин В. М.**

Тема: создание security pipeline для GitHub Actions с акцентом на контроль происхождения артефактов, безопасный checkout, SBOM, checksums и защиту от рисков при работе с Git submodules.

Теоретический кейс: **CVE-2024-32002** — уязвимость Git, связанная с возможностью удаленного выполнения кода при рекурсивном клонировании репозитория с submodules на case-insensitive файловых системах.

## Что проверяет pipeline

- SAST: CodeQL и Bandit для Python-кода;
- SCA: `pip-audit` для зависимостей Python;
- secret scanning: `detect-secrets` и учебное Semgrep-правило;
- workflow audit: `zizmor` для GitHub Actions workflow;
- IaC/container: Trivy filesystem scan;
- artifact provenance: сборка архива, SHA-256 checksum, SBOM и attestation;
- отчеты сохраняются в artifacts GitHub Actions.

## Как запустить

1. Создать новый публичный или приватный репозиторий на GitHub.
2. Загрузить в него содержимое этого архива.
3. Открыть вкладку **Actions**.
4. Запустить workflow **Security pipeline - artifact provenance focus** через `workflow_dispatch` или сделать push в ветку `main`.
5. Проверить artifacts: `security-reports-turin`, `artifact-provenance-turin`, `sbom-turin`.

## Ожидаемый учебный результат

Pipeline должен показать демонстрационные security findings: учебный псевдосекрет, небезопасную команду shell, замечания по Dockerfile и предупреждения по workflow. Все уязвимые фрагменты являются демонстрационными и предназначены только для проверки работы security pipeline.

## Структура

```text
.github/workflows/security.yml    # основной GitHub Actions pipeline
.github/dependabot.yml            # обновления зависимостей и actions
semgrep/demo-secrets.yml          # учебное правило поиска псевдосекретов
src/app.py                        # демонстрационное Python-приложение
tests/test_app.py                 # простые тесты
Dockerfile                        # демонстрационный Dockerfile
docs/pipeline-description.md      # описание pipeline для отчета
workflows/artifact-provenance.yml # отдельный workflow из приложения к курсовой
requirements.txt                  # зависимости проекта
```

## Важно

В репозитории нет настоящих секретов. Строки вида `DEMO_TOKEN_...` специально добавлены как учебные псевдосекреты для проверки Semgrep/detect-secrets.
